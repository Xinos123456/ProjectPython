import os
from PIL import Image
from torch.utils.data import Dataset
import numpy as np

class CarvanaDataset(Dataset):
    def __init__(self, image_dir, mask_dir,transform=None, n_image=None):
        self.image_dir = image_dir
        self.mask_dir = mask_dir
        self.transform = transform
        self.images = os.listdir(image_dir)
        self.n_image = n_image

    def __len__(self):
        if self.n_image is None : 
            return len(self.images)
        else : 
            return min(len(self.images), self.n_image)


    def __getitem__(self, index):
        if self.n_image is not None : 
            assert index < self.n_image
        img_path = os.path.join(self.image_dir, self.images[index])
        mask_path = os.path.join(self.mask_dir, self.images[index])
        image = np.array(Image.open(img_path).convert("RGB"))
        mask = np.array(Image.open(mask_path).convert("L"), dtype=np.float32)
        mask[mask == 255.0] = 1.0

        if self.transform is not None:
            augmentations = self.transform(image=image, mask=mask)
            image = augmentations["image"]
            mask = augmentations["mask"]

        return image, mask

if __name__ =='__main__' :
    import albumentations as A
    from albumentations.pytorch import ToTensorV2
    val_transforms = A.Compose(
            [
                A.Resize(height=448, width=448),
                A.Normalize(
                    mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225],
                    max_pixel_value=255.0,
                ),
                ToTensorV2(),
            ],
        )
    dataset = CarvanaDataset("data/val_images/", "data/val_masks/", val_transforms, n_image=10)
